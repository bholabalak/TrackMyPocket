package com.example.laptop.trackmypocket;

/**
 * Created by laptop on 07-07-2018.
 */
import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class CustomAdapter extends BaseAdapter {
    Context context;
    ArrayList categoryList;
    ArrayList Id;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, ArrayList categoryList, ArrayList Id) {
        this.context = context;
        this.categoryList = categoryList;
        this.Id = Id;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return categoryList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.activity_listview, null);
        TextView country = (TextView) view.findViewById(R.id.txtCategoryName);
        TextView txtCategoryId = (TextView) view.findViewById(R.id.txtCategoryId);
        country.setText(categoryList.get(i).toString());
        txtCategoryId.setText(Id.get(i).toString());
        return view;
    }
}